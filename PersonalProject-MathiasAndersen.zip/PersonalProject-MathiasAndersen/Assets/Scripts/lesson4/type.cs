﻿internal class type
{
}